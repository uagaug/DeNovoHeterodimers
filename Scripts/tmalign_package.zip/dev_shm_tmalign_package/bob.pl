for my $d (`ls -d */`)
{
	chomp($d);
	system("ls $d/middles/*.pdb > $d/middle_list\n");
	for my $side (`ls $d/sides/*.pdb`)
	{
		chomp($side);
		print "perl /dev/shm/pdb_find.pl $d/middle_list $side $side.out\n";
	}
}
