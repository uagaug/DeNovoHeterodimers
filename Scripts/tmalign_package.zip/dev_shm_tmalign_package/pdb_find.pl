#!/usr/bin/perl
use File::Basename;
unless(exists $ARGV[1])
{
	print "pdb_find.pl <LIST> <PDB>\n";
	die();
}
my $list = $ARGV[0];unless(-e $list){die("'$list' list does not exist");}
my $c = $ARGV[1];unless(-e $c){die("'$c' pdb does not exist");}
my $C = basename($c);

my @PRINT;
open(LIST,$list);
while($pdb = <LIST>)
{
	chomp($pdb);
	my $print = $c."\t".$pdb;
	for my $t (`/dev/shm/TMalign $c $pdb -a`)
	{
		chomp($t);
		my @tm = split(/[\s\=\(\)\,\:]+/,$t);
		if($tm[0] eq "Length"){$print .= "\t".$tm[3];}
		elsif($tm[0] eq "Aligned"){$print .= "\t".$tm[2]."\t".$tm[4]."\t".$tm[7];}
		elsif($tm[0] eq "TM-score"){$print .= "\t".$tm[1];}
	}
	push(@PRINT,$print);
}
close(LIST);
open(OUT,">$ARGV[2]");
for my $print (@PRINT){print OUT $print."\n";}
close(OUT);
